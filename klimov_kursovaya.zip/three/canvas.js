'use strict';
let camera, renderer, scene, molecule;
const vanDerWaals= {
    1 : 1.2,
    30 :1.39,
    2 : 1.40,
    29 : 1.40,
    9 : 1.47,
    8 : 1.52,
    4 : 1.53,
    10 : 1.54,
    7 : 1.55,
    80 : 1.55,
    48 : 1.58,
    28 : 1.63,
    6 : 1.7
};

const animation = function () {
  requestAnimationFrame(animation);
  molecule.position.z+=0.001;
  renderer.render(scene,camera);
};

const init = function initScene() {
    camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 10000 );
    camera.position.set(10,0,10);
    camera.lookAt(new THREE.Vector3(0,0,0));
    renderer = new THREE.WebGLRenderer();
    renderer.setSize( window.innerWidth, window.innerHeight );
    renderer.autoClear = true;
    renderer.shadowMapType = THREE.PCFSoftShadowMap;
    renderer.shadowMapEnabled = true;
    renderer.setClearColor(new THREE.Color(0x303030));
    document.body.appendChild( renderer.domElement );
};

const parseJson = function (text) {
    const parsedJson = JSON.parse(text)['PC_Compounds'][0];
    const conformers = parsedJson['coords'][0]['conformers'][0];
    const xCoords = conformers['x'];
    const yCoords = conformers['y'];
    const zCoords = conformers['z'];
    const radius = parsedJson['atoms']['element'].map((el) => vanDerWaals[el]);

    const coords = [];
    for (let i = 0 ; i < xCoords.length ; i++){
        coords.push({x : xCoords[i] , y : yCoords[i] , z : zCoords[i] , r : radius[i]});
    }

    scene = new THREE.Scene();
    const ambient = new THREE.AmbientLight(0x202020);
    const light = new THREE.PointLight( 0xffffff, 1, 100 );
    light.position.set( 10, 2, 10 );
    light.castShadow = true;
    light.shadowDarkness = 0.2;
    scene.add( light );
    scene.add(ambient);
    molecule = new THREE.Mesh();

    for(let sphereCoords of coords){
        const sphereGeometry = new THREE.SphereGeometry(sphereCoords.r,32,32);
        const sphereMaterial = new THREE.MeshPhongMaterial( { color: 0x00ff00});
        const sphere = new THREE.Mesh(sphereGeometry,sphereMaterial);
        sphere.position.set(sphereCoords.x,sphereCoords.y,sphereCoords.z);
        sphere.castShadow = true;
        sphere.receiveShadow = true;
        molecule.add(sphere);
    }

    scene.add(molecule);
    requestAnimationFrame(animation);
};

const getByHttp = function httpRequest(id,callback) {
    const xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() {
        if (xmlHttp.readyState === 4 && xmlHttp.status === 200)
            callback(xmlHttp.responseText);
    };
    xmlHttp.open("GET", `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${id}/JSON?record_type=3d`, true);
    xmlHttp.send(null);
};

const getByFile = function jsonFile(file,callback) {
    const filename = file.name;

    if(/\w+.json/.test(filename)){
        const reader = new FileReader();

        reader.onload = function (event) {
            callback(event.target.result)
        };

        reader.readAsText(file);
    }
};

init();